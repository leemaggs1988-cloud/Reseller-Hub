import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const payload = await req.json();

    if (payload.type === "checkout.session.completed") {
      const session = payload.data.object;
      const userId = session.metadata?.user_id;

      if (userId) {
        const subscriptionEndDate = new Date();
        subscriptionEndDate.setMonth(subscriptionEndDate.getMonth() + 1);

        await supabase
          .from("profiles")
          .update({
            subscription_tier: "premium",
            subscription_ends_at: subscriptionEndDate.toISOString(),
          })
          .eq("id", userId);

        console.log(`Subscription activated for user ${userId}`);
      }
    }

    if (payload.type === "invoice.payment_succeeded") {
      const invoice = payload.data.object;
      const userId = invoice.metadata?.user_id;

      if (userId) {
        const subscriptionEndDate = new Date();
        subscriptionEndDate.setMonth(subscriptionEndDate.getMonth() + 1);

        await supabase
          .from("profiles")
          .update({
            subscription_tier: "premium",
            subscription_ends_at: subscriptionEndDate.toISOString(),
          })
          .eq("id", userId);

        console.log(`Subscription renewed for user ${userId}`);
      }
    }

    return new Response(
      JSON.stringify({ received: true }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in stripe-webhook:", error);
    return new Response(
      JSON.stringify({ error: "Webhook processing failed" }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
