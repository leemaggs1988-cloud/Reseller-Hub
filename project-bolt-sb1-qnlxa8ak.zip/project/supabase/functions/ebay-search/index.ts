import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SearchRequest {
  keywords: string;
  postcode: string;
  maxDistance: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { keywords, postcode, maxDistance }: SearchRequest = await req.json();

    const items = [
      {
        itemId: "demo-1",
        title: "Vintage Leather Jacket - Collection Only",
        price: "£45.00",
        imageUrl: "https://images.pexels.com/photos/1050244/pexels-photo-1050244.jpeg?auto=compress&cs=tinysrgb&w=400",
        location: postcode || "London",
        endTime: "2h 15m",
        distance: `${Math.floor(Math.random() * 10) + 1} miles`,
      },
      {
        itemId: "demo-2",
        title: "Antique Wooden Dining Table Set",
        price: "£120.00",
        imageUrl: "https://images.pexels.com/photos/1350789/pexels-photo-1350789.jpeg?auto=compress&cs=tinysrgb&w=400",
        location: postcode || "London",
        endTime: "5h 42m",
        distance: `${Math.floor(Math.random() * 10) + 1} miles`,
      },
      {
        itemId: "demo-3",
        title: "Retro Gaming Console Bundle",
        price: "£85.00",
        imageUrl: "https://images.pexels.com/photos/371924/pexels-photo-371924.jpeg?auto=compress&cs=tinysrgb&w=400",
        location: postcode || "London",
        endTime: "1h 30m",
        distance: `${Math.floor(Math.random() * 10) + 1} miles`,
      },
      {
        itemId: "demo-4",
        title: "Designer Handbag - Excellent Condition",
        price: "£65.00",
        imageUrl: "https://images.pexels.com/photos/1152077/pexels-photo-1152077.jpeg?auto=compress&cs=tinysrgb&w=400",
        location: postcode || "London",
        endTime: "3h 20m",
        distance: `${Math.floor(Math.random() * 10) + 1} miles`,
      },
      {
        itemId: "demo-5",
        title: "Bicycle - Mountain Bike Collection Only",
        price: "£180.00",
        imageUrl: "https://images.pexels.com/photos/276517/pexels-photo-276517.jpeg?auto=compress&cs=tinysrgb&w=400",
        location: postcode || "London",
        endTime: "6h 10m",
        distance: `${Math.floor(Math.random() * 10) + 1} miles`,
      },
    ];

    return new Response(
      JSON.stringify({ items, total: items.length }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in ebay-search:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error", items: [] }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
