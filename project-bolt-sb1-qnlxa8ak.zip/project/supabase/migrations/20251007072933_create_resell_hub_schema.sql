/*
  # Resell Hub Database Schema

  ## Overview
  Complete database schema for the Resell Hub mobile app - a platform for the reselling community
  to discover locations, find eBay deals, and share their finds.

  ## New Tables

  ### 1. profiles
  User profile information extending Supabase auth.users
  - `id` (uuid, FK to auth.users) - Primary key
  - `username` (text, unique) - Display name
  - `avatar_url` (text) - Profile picture URL
  - `bio` (text) - User bio
  - `postcode` (text) - User's postcode for local deals
  - `subscription_tier` (text) - free, premium
  - `subscription_ends_at` (timestamptz) - Subscription expiry
  - `created_at` (timestamptz) - Account creation
  - `updated_at` (timestamptz) - Last update

  ### 2. locations
  Physical locations like charity shops, boot sales, flea markets
  - `id` (uuid) - Primary key
  - `name` (text) - Location name
  - `type` (text) - charity_shop, boot_sale, flea_market
  - `address` (text) - Street address
  - `postcode` (text) - Postcode
  - `latitude` (numeric) - GPS latitude
  - `longitude` (numeric) - GPS longitude
  - `phone` (text) - Contact number
  - `opening_hours` (jsonb) - Opening hours data
  - `average_rating` (numeric) - Average user rating
  - `total_ratings` (int) - Number of ratings
  - `created_by` (uuid, FK) - User who added it
  - `created_at` (timestamptz) - When added
  - `updated_at` (timestamptz) - Last update

  ### 3. location_tips
  User-submitted tips for locations
  - `id` (uuid) - Primary key
  - `location_id` (uuid, FK) - Related location
  - `user_id` (uuid, FK) - User who posted
  - `tip_text` (text) - The tip content
  - `created_at` (timestamptz) - When posted

  ### 4. location_ratings
  User ratings for locations
  - `id` (uuid) - Primary key
  - `location_id` (uuid, FK) - Related location
  - `user_id` (uuid, FK) - User who rated
  - `rating` (int) - Rating value (1-5)
  - `created_at` (timestamptz) - When rated

  ### 5. posts
  Social feed posts (pickups, tips, discussions)
  - `id` (uuid) - Primary key
  - `user_id` (uuid, FK) - Post author
  - `content` (text) - Post text
  - `image_url` (text) - Photo of find
  - `post_type` (text) - pickup, tip, discussion
  - `likes_count` (int) - Number of likes
  - `comments_count` (int) - Number of comments
  - `created_at` (timestamptz) - When posted
  - `updated_at` (timestamptz) - Last update

  ### 6. post_likes
  Likes on posts
  - `id` (uuid) - Primary key
  - `post_id` (uuid, FK) - Related post
  - `user_id` (uuid, FK) - User who liked
  - `created_at` (timestamptz) - When liked

  ### 7. post_comments
  Comments on posts
  - `id` (uuid) - Primary key
  - `post_id` (uuid, FK) - Related post
  - `user_id` (uuid, FK) - Comment author
  - `content` (text) - Comment text
  - `created_at` (timestamptz) - When posted
  - `updated_at` (timestamptz) - Last update

  ### 8. follows
  User follow relationships
  - `id` (uuid) - Primary key
  - `follower_id` (uuid, FK) - User doing the following
  - `following_id` (uuid, FK) - User being followed
  - `created_at` (timestamptz) - When followed

  ### 9. saved_deals
  eBay deals saved by users (premium feature)
  - `id` (uuid) - Primary key
  - `user_id` (uuid, FK) - User who saved
  - `ebay_item_id` (text) - eBay item ID
  - `item_data` (jsonb) - Cached item data
  - `created_at` (timestamptz) - When saved

  ## Security
  - RLS enabled on all tables
  - Policies enforce user ownership and authentication
  - Premium features restricted by subscription tier

  ## Notes
  - All timestamps use UTC
  - Indexes added for performance on foreign keys and common queries
  - Subscription tier checked via policies for premium features
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE NOT NULL,
  avatar_url text,
  bio text DEFAULT '',
  postcode text,
  subscription_tier text DEFAULT 'free' CHECK (subscription_tier IN ('free', 'premium')),
  subscription_ends_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create locations table
CREATE TABLE IF NOT EXISTS locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('charity_shop', 'boot_sale', 'flea_market')),
  address text NOT NULL,
  postcode text NOT NULL,
  latitude numeric NOT NULL,
  longitude numeric NOT NULL,
  phone text,
  opening_hours jsonb DEFAULT '{}',
  average_rating numeric DEFAULT 0 CHECK (average_rating >= 0 AND average_rating <= 5),
  total_ratings int DEFAULT 0,
  created_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create location_tips table
CREATE TABLE IF NOT EXISTS location_tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  tip_text text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create location_ratings table
CREATE TABLE IF NOT EXISTS location_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_id uuid NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  rating int NOT NULL CHECK (rating >= 1 AND rating <= 5),
  created_at timestamptz DEFAULT now(),
  UNIQUE(location_id, user_id)
);

-- Create posts table
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  image_url text,
  post_type text DEFAULT 'pickup' CHECK (post_type IN ('pickup', 'tip', 'discussion')),
  likes_count int DEFAULT 0,
  comments_count int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create post_likes table
CREATE TABLE IF NOT EXISTS post_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(post_id, user_id)
);

-- Create post_comments table
CREATE TABLE IF NOT EXISTS post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id uuid NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create follows table
CREATE TABLE IF NOT EXISTS follows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  following_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id)
);

-- Create saved_deals table (premium feature)
CREATE TABLE IF NOT EXISTS saved_deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  ebay_item_id text NOT NULL,
  item_data jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, ebay_item_id)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_locations_postcode ON locations(postcode);
CREATE INDEX IF NOT EXISTS idx_locations_type ON locations(type);
CREATE INDEX IF NOT EXISTS idx_locations_coordinates ON locations(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_location_tips_location ON location_tips(location_id);
CREATE INDEX IF NOT EXISTS idx_location_ratings_location ON location_ratings(location_id);
CREATE INDEX IF NOT EXISTS idx_posts_user ON posts(user_id);
CREATE INDEX IF NOT EXISTS idx_posts_created_at ON posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_post_likes_post ON post_likes(post_id);
CREATE INDEX IF NOT EXISTS idx_post_comments_post ON post_comments(post_id);
CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following ON follows(following_id);
CREATE INDEX IF NOT EXISTS idx_saved_deals_user ON saved_deals(user_id);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE location_tips ENABLE ROW LEVEL SECURITY;
ALTER TABLE location_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE post_comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_deals ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Locations policies
CREATE POLICY "Locations are viewable by everyone"
  ON locations FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create locations"
  ON locations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Location creators can update their locations"
  ON locations FOR UPDATE
  TO authenticated
  USING (auth.uid() = created_by)
  WITH CHECK (auth.uid() = created_by);

-- Location tips policies
CREATE POLICY "Location tips are viewable by everyone"
  ON location_tips FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create location tips"
  ON location_tips FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own tips"
  ON location_tips FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Location ratings policies
CREATE POLICY "Location ratings are viewable by everyone"
  ON location_ratings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create ratings"
  ON location_ratings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own ratings"
  ON location_ratings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Posts policies
CREATE POLICY "Posts are viewable by everyone"
  ON posts FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create posts"
  ON posts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own posts"
  ON posts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own posts"
  ON posts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Post likes policies
CREATE POLICY "Post likes are viewable by everyone"
  ON post_likes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can like posts"
  ON post_likes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can unlike posts"
  ON post_likes FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Post comments policies
CREATE POLICY "Post comments are viewable by everyone"
  ON post_comments FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can comment on posts"
  ON post_comments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own comments"
  ON post_comments FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own comments"
  ON post_comments FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Follows policies
CREATE POLICY "Follows are viewable by everyone"
  ON follows FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can follow others"
  ON follows FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = follower_id);

CREATE POLICY "Users can unfollow others"
  ON follows FOR DELETE
  TO authenticated
  USING (auth.uid() = follower_id);

-- Saved deals policies (premium feature)
CREATE POLICY "Users can view their own saved deals"
  ON saved_deals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Premium users can save deals"
  ON saved_deals FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = user_id AND
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.subscription_tier = 'premium'
      AND (profiles.subscription_ends_at IS NULL OR profiles.subscription_ends_at > now())
    )
  );

CREATE POLICY "Users can delete their own saved deals"
  ON saved_deals FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Function to update location rating averages
CREATE OR REPLACE FUNCTION update_location_rating()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE locations
  SET
    average_rating = (
      SELECT COALESCE(AVG(rating), 0)
      FROM location_ratings
      WHERE location_id = NEW.location_id
    ),
    total_ratings = (
      SELECT COUNT(*)
      FROM location_ratings
      WHERE location_id = NEW.location_id
    ),
    updated_at = now()
  WHERE id = NEW.location_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update location ratings
DROP TRIGGER IF EXISTS trigger_update_location_rating ON location_ratings;
CREATE TRIGGER trigger_update_location_rating
  AFTER INSERT OR UPDATE OR DELETE ON location_ratings
  FOR EACH ROW
  EXECUTE FUNCTION update_location_rating();

-- Function to update post like counts
CREATE OR REPLACE FUNCTION update_post_likes_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE posts
    SET likes_count = likes_count + 1
    WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE posts
    SET likes_count = GREATEST(likes_count - 1, 0)
    WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update post likes count
DROP TRIGGER IF EXISTS trigger_update_post_likes_count ON post_likes;
CREATE TRIGGER trigger_update_post_likes_count
  AFTER INSERT OR DELETE ON post_likes
  FOR EACH ROW
  EXECUTE FUNCTION update_post_likes_count();

-- Function to update post comment counts
CREATE OR REPLACE FUNCTION update_post_comments_count()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE posts
    SET comments_count = comments_count + 1
    WHERE id = NEW.post_id;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE posts
    SET comments_count = GREATEST(comments_count - 1, 0)
    WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update post comments count
DROP TRIGGER IF EXISTS trigger_update_post_comments_count ON post_comments;
CREATE TRIGGER trigger_update_post_comments_count
  AFTER INSERT OR DELETE ON post_comments
  FOR EACH ROW
  EXECUTE FUNCTION update_post_comments_count();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers to update updated_at
DROP TRIGGER IF EXISTS trigger_profiles_updated_at ON profiles;
CREATE TRIGGER trigger_profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trigger_posts_updated_at ON posts;
CREATE TRIGGER trigger_posts_updated_at
  BEFORE UPDATE ON posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS trigger_post_comments_updated_at ON post_comments;
CREATE TRIGGER trigger_post_comments_updated_at
  BEFORE UPDATE ON post_comments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();