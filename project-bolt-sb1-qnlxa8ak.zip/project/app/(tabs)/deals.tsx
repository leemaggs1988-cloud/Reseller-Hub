import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput, Image, ActivityIndicator, RefreshControl } from 'react-native';
import { Search, MapPin, Clock, TrendingUp, Heart, ListFilter as Filter } from 'lucide-react-native';
import { useAuth } from '@/contexts/AuthContext';

interface EbayItem {
  itemId: string;
  title: string;
  price: string;
  imageUrl: string;
  location: string;
  endTime: string;
  distance?: string;
}

export default function DealsScreen() {
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');
  const [postcode, setPostcode] = useState(profile?.postcode || '');
  const [deals, setDeals] = useState<EbayItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [maxDistance, setMaxDistance] = useState('10');

  const isPremium = profile?.subscription_tier === 'premium' &&
    (!profile.subscription_ends_at || new Date(profile.subscription_ends_at) > new Date());

  useEffect(() => {
    if (postcode) {
      fetchDeals();
    }
  }, []);

  const fetchDeals = async () => {
    if (!postcode) {
      return;
    }

    setLoading(true);
    try {
      const response = await fetch(
        `${process.env.EXPO_PUBLIC_SUPABASE_URL}/functions/v1/ebay-search`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            keywords: searchQuery || 'vintage',
            postcode: postcode,
            maxDistance: maxDistance,
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch deals');
      }

      const data = await response.json();
      setDeals(data.items || []);
    } catch (error) {
      console.error('Error fetching deals:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchDeals();
    setRefreshing(false);
  };

  const handleSearch = () => {
    fetchDeals();
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Local eBay Deals</Text>
        <Text style={styles.subtitle}>Collection-only listings near you</Text>
      </View>

      <View style={styles.searchContainer}>
        <View style={styles.searchBar}>
          <Search size={20} color="#6b7280" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search items..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
          />
        </View>

        <View style={styles.postcodeBar}>
          <MapPin size={20} color="#6b7280" style={styles.searchIcon} />
          <TextInput
            style={styles.postcodeInput}
            placeholder="Enter postcode"
            value={postcode}
            onChangeText={setPostcode}
            autoCapitalize="characters"
          />
          <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
            <Text style={styles.searchButtonText}>Search</Text>
          </TouchableOpacity>
        </View>

        {isPremium && (
          <View style={styles.filterRow}>
            <Filter size={16} color="#3b82f6" />
            <Text style={styles.filterLabel}>Max Distance (miles):</Text>
            <TextInput
              style={styles.distanceInput}
              value={maxDistance}
              onChangeText={setMaxDistance}
              keyboardType="number-pad"
              maxLength={3}
            />
          </View>
        )}

        {!isPremium && (
          <View style={styles.premiumBanner}>
            <TrendingUp size={16} color="#8b5cf6" />
            <Text style={styles.premiumText}>
              Upgrade to Premium for advanced filters
            </Text>
          </View>
        )}
      </View>

      <ScrollView
        style={styles.dealsList}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />
        }
      >
        {loading && !refreshing ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color="#3b82f6" />
            <Text style={styles.loadingText}>Searching for deals...</Text>
          </View>
        ) : deals.length === 0 && postcode ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>No deals found</Text>
            <Text style={styles.emptySubtext}>
              Try adjusting your search or postcode
            </Text>
          </View>
        ) : deals.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Text style={styles.emptyText}>Enter your postcode to start</Text>
            <Text style={styles.emptySubtext}>
              Find collection-only eBay listings near you
            </Text>
          </View>
        ) : (
          deals.map((deal) => (
            <View key={deal.itemId} style={styles.dealCard}>
              <Image
                source={{ uri: deal.imageUrl }}
                style={styles.dealImage}
                resizeMode="cover"
              />
              <View style={styles.dealContent}>
                <Text style={styles.dealTitle} numberOfLines={2}>
                  {deal.title}
                </Text>
                <Text style={styles.dealPrice}>{deal.price}</Text>
                <View style={styles.dealMeta}>
                  <View style={styles.dealMetaItem}>
                    <MapPin size={14} color="#6b7280" />
                    <Text style={styles.dealMetaText}>{deal.location}</Text>
                  </View>
                  {deal.distance && (
                    <View style={styles.dealMetaItem}>
                      <Text style={styles.dealDistance}>{deal.distance}</Text>
                    </View>
                  )}
                </View>
                <View style={styles.dealFooter}>
                  <View style={styles.dealMetaItem}>
                    <Clock size={14} color="#ef4444" />
                    <Text style={styles.dealEndTime}>{deal.endTime}</Text>
                  </View>
                  {isPremium && (
                    <TouchableOpacity style={styles.saveButton}>
                      <Heart size={18} color="#6b7280" />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f9fafb',
  },
  header: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 24,
    paddingTop: 60,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#1f2937',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    color: '#6b7280',
  },
  searchContainer: {
    backgroundColor: '#ffffff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#1f2937',
  },
  postcodeBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9fafb',
    borderRadius: 12,
    padding: 12,
  },
  postcodeInput: {
    flex: 1,
    fontSize: 16,
    color: '#1f2937',
  },
  searchButton: {
    backgroundColor: '#3b82f6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  searchButtonText: {
    color: '#ffffff',
    fontSize: 14,
    fontWeight: '600',
  },
  filterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    padding: 8,
    backgroundColor: '#eff6ff',
    borderRadius: 8,
  },
  filterLabel: {
    fontSize: 14,
    color: '#3b82f6',
    marginLeft: 4,
    flex: 1,
  },
  distanceInput: {
    backgroundColor: '#ffffff',
    borderWidth: 1,
    borderColor: '#3b82f6',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 4,
    width: 50,
    textAlign: 'center',
  },
  premiumBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f3e8ff',
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
  },
  premiumText: {
    fontSize: 13,
    color: '#8b5cf6',
    marginLeft: 8,
    fontWeight: '600',
  },
  dealsList: {
    flex: 1,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#6b7280',
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#6b7280',
  },
  dealCard: {
    backgroundColor: '#ffffff',
    marginHorizontal: 16,
    marginVertical: 8,
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  dealImage: {
    width: '100%',
    height: 200,
    backgroundColor: '#f3f4f6',
  },
  dealContent: {
    padding: 16,
  },
  dealTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 8,
    lineHeight: 22,
  },
  dealPrice: {
    fontSize: 20,
    fontWeight: '700',
    color: '#10b981',
    marginBottom: 12,
  },
  dealMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
    justifyContent: 'space-between',
  },
  dealMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  dealMetaText: {
    fontSize: 13,
    color: '#6b7280',
    marginLeft: 4,
  },
  dealDistance: {
    fontSize: 12,
    color: '#3b82f6',
    fontWeight: '600',
  },
  dealFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dealEndTime: {
    fontSize: 12,
    color: '#ef4444',
    marginLeft: 4,
  },
  saveButton: {
    padding: 4,
  },
});
