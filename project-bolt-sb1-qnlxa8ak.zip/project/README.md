# Resell Hub - Mobile Reselling Community App

A cross-platform mobile app built with React Native and Expo for the reselling community to discover locations, find eBay deals, and share finds.

## Features

### Core Features
- **Location Discovery**: Map view with nearby charity shops, boot sales, and flea markets
- **eBay Local Deals**: Search collection-only eBay listings by postcode with distance filtering
- **Social Feed**: Share pickups, post tips, and engage with the community
- **User Profiles**: Manage account, subscription, and preferences
- **Premium Subscription**: Advanced filters, deal alerts, and ad-free experience (£2/month)

### Technical Features
- Email/password authentication via Supabase Auth
- Real-time database with RLS policies
- React Native Maps integration
- Edge Functions for eBay API and Stripe webhooks
- Offline-first architecture with local caching

## Tech Stack

- **Framework**: React Native + Expo SDK 54
- **Navigation**: Expo Router (file-based routing)
- **Backend**: Supabase (PostgreSQL + Auth + Edge Functions)
- **Maps**: React Native Maps
- **Icons**: Lucide React Native
- **Language**: TypeScript
- **Styling**: StyleSheet API

## Project Structure

```
app/
├── (auth)/              # Authentication screens
│   ├── login.tsx
│   └── signup.tsx
├── (tabs)/              # Main app tabs
│   ├── index.tsx        # Map/Locations screen
│   ├── deals.tsx        # eBay Deals screen
│   ├── social.tsx       # Social Feed screen
│   └── profile.tsx      # Profile screen
├── _layout.tsx          # Root layout with AuthProvider
└── index.tsx            # Entry point with auth routing

contexts/
└── AuthContext.tsx      # Authentication state management

lib/
└── supabase.ts          # Supabase client configuration

supabase/functions/
├── ebay-search/         # eBay API integration (demo mode)
└── stripe-webhook/      # Stripe subscription webhooks
```

## Database Schema

### Tables
- **profiles**: User profiles extending auth.users
- **locations**: Physical reselling locations (shops, markets)
- **location_tips**: User-submitted tips for locations
- **location_ratings**: User ratings for locations
- **posts**: Social feed posts (pickups, tips, discussions)
- **post_likes**: Likes on posts
- **post_comments**: Comments on posts
- **follows**: User follow relationships
- **saved_deals**: Premium feature - saved eBay deals

## Setup Instructions

### Prerequisites
- Node.js 18+ installed
- Expo CLI (`npm install -g expo-cli`)
- Supabase account (already configured)

### Environment Variables
Already configured in `.env`:
```
EXPO_PUBLIC_SUPABASE_URL=your_supabase_url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### Installation
```bash
npm install
```

### Development
```bash
npm run dev
```

### Build for Production
```bash
npm run build:web
```

## API Integration

### eBay Finding API
The app includes a placeholder for eBay Finding API integration. To connect the real eBay API:

1. Register at [eBay Developers Program](https://developer.ebay.com/)
2. Get your API credentials (App ID)
3. Update `supabase/functions/ebay-search/index.ts` with the actual API implementation
4. Replace demo data with real eBay Finding API calls

**Current Implementation**: Demo mode with mock data showing example listings with Pexels images.

### Stripe Integration
For subscription payments:

1. Create a Stripe account at [stripe.com](https://stripe.com)
2. Get your API keys from the Stripe dashboard
3. Configure webhook endpoint: `https://your-project.supabase.co/functions/v1/stripe-webhook`
4. The webhook handler is already deployed and ready to activate subscriptions

## Key Features Implementation

### Authentication
- Email/password signup and login
- Automatic profile creation on signup
- Session management with AuthContext
- Protected routes with automatic redirection

### Map View
- React Native Maps with custom markers
- Filter by location type (charity shops, boot sales, flea markets)
- Search functionality
- Location ratings and tips
- Add new locations (FAB button)

### eBay Deals
- Postcode-based search
- Distance filtering (Premium feature)
- Mock data in demo mode
- Save deals (Premium feature)
- Responsive cards with images

### Social Feed
- Create posts (pickups, tips, discussions)
- Like and comment on posts
- Real-time updates
- User avatars and timestamps
- Pull-to-refresh

### Profile & Subscription
- Edit profile (username, bio, postcode)
- Subscription status display
- Upgrade to Premium flow
- Account information
- Sign out functionality

## Premium Features

Premium subscription (£2/month) unlocks:
- Advanced eBay filters (distance, category, price)
- Save unlimited deals
- Deal alerts
- Ad-free experience
- Priority support

## Security

- Row Level Security (RLS) on all tables
- User data access restricted to authenticated users
- Premium features gated by subscription status
- Secure API calls through Edge Functions
- No API keys exposed to client

## Scalability

Designed for 1,000+ users with:
- Database indexes on common queries
- Efficient pagination (limit 50 items)
- Optimized image loading with Pexels CDN
- Edge Functions for API rate limiting
- Caching strategies for offline support

## Development Notes

### Platform Support
- Primary platform: Web (mobile-optimized)
- iOS/Android: Full support via Expo
- Web: Maps work with fallback location

### Known Limitations
- eBay API in demo mode (requires API key for production)
- Stripe integration requires manual configuration
- Image uploads not yet implemented
- Comments view not yet implemented

## Future Enhancements

- Push notifications for deal alerts
- Advanced map clustering
- Image upload for posts and profile
- Full comments system
- In-app messaging between users
- Analytics dashboard
- Location check-ins
- Seller ratings

## Support

For issues or questions, contact the development team or check the documentation at the Supabase dashboard.

## License

Private - All rights reserved
